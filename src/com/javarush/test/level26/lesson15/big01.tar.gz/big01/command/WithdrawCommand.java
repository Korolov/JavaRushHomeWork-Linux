package com.javarush.test.level26.lesson15.big01.command;


import com.javarush.test.level26.lesson15.big01.ConsoleHelper;
import com.javarush.test.level26.lesson15.big01.CurrencyManipulator;
import com.javarush.test.level26.lesson15.big01.CurrencyManipulatorFactory;
import com.javarush.test.level26.lesson15.big01.exception.InterruptOperationException;
import com.javarush.test.level26.lesson15.big01.exception.NotEnoughMoneyException;


/**
 * Created by alexander on 28.03.16.
 */
class WithdrawCommand implements Command
{
    @Override
    public void execute() throws InterruptOperationException
    {
        String currency = ConsoleHelper.askCurrencyCode();
        CurrencyManipulator manipulator = CurrencyManipulatorFactory.getManipulatorByCurrencyCode(currency);

        boolean isDataCorrect = false;
        boolean isOperation = false;
        int amount = 0;
        do
        {
            do
            {
                try
                {
                    ConsoleHelper.writeMessage("Please enter sum of money ");
                    amount = Integer.parseInt(ConsoleHelper.readString());
                    if (manipulator.isAmountAvailable(amount))
                        isDataCorrect = true;
                }
                catch (NumberFormatException e)
                {
                    ConsoleHelper.writeMessage("ERROR! You did not enter a valid number");

                }
            }
            while (isDataCorrect == false);
            try
            {
               manipulator.withdrawAmount(amount);
                isOperation = true;
            }
            catch (NotEnoughMoneyException e)
            {
                ConsoleHelper.writeMessage("No money exception");
            }
        }
        while (isOperation==false);
    }


    }
