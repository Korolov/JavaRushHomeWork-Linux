package com.javarush.test.level26.lesson15.big01.command;

import com.javarush.test.level26.lesson15.big01.ConsoleHelper;
import com.javarush.test.level26.lesson15.big01.CurrencyManipulator;
import com.javarush.test.level26.lesson15.big01.CurrencyManipulatorFactory;



/**
 * Created by alexander on 28.03.16.
 */
class InfoCommand implements Command
{
    @Override
    public void execute()
    {
        boolean isMoney = false;
        for (Object e : CurrencyManipulatorFactory.getAllCurrencyManipulators())
        {
            CurrencyManipulator m = (CurrencyManipulator) e;
            if(m.hasMoney()){
                if(m.getTotalAmount()>0){
                    ConsoleHelper.writeMessage(m.getCurrencyCode() + " - " + m.getTotalAmount());
                    isMoney=true;
                }
            }
        }
        if(!isMoney){
            ConsoleHelper.writeMessage("No money available.");
        }
    }
}
