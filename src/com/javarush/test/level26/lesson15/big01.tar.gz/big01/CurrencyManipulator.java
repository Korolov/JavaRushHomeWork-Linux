package com.javarush.test.level26.lesson15.big01;



import com.javarush.test.level26.lesson15.big01.exception.NotEnoughMoneyException;

import java.util.*;


/**
 * Created by alexander on 28.03.16.
 */
public class CurrencyManipulator
{
    private String currencyCode;
    private Map<Integer, Integer> denominations=new HashMap<>();

    public String getCurrencyCode()
    {
        return currencyCode;
    }

    public CurrencyManipulator(String currencyCode)
    {
        this.currencyCode = currencyCode;
    }

    public void addAmount(int denomination, int count){
        if(denominations.containsKey(denomination))
            denominations.put(denomination,denominations.get(denomination)+count);
        else
            denominations.put(denomination,count);

    }

    public int getTotalAmount(){
        int count=0;
        for(Map.Entry entry:denominations.entrySet()){
            count=count+(int)entry.getKey()*(int)entry.getValue();
        }
        return count;
    }

   public boolean hasMoney(){
       return denominations.size()>0;
   }

    public boolean isAmountAvailable(int expectedAmount){
        return expectedAmount<=getTotalAmount();
    }

    public Map<Integer, Integer> withdrawAmount(int expectedAmount) throws NotEnoughMoneyException,ConcurrentModificationException
    {
        SortedMap<Integer,Integer> used=new TreeMap<>();
        TreeMap sortedMap=new TreeMap<>();
        sortedMap.putAll(denominations);
        do{

            if(sortedMap.containsKey(expectedAmount)){
                if((int)sortedMap.get(expectedAmount)>=1){
                    if(used.containsKey(expectedAmount))
                        used.put(expectedAmount,used.get(expectedAmount)+1);
                    else
                        used.put(expectedAmount,1);
                    sortedMap.put(expectedAmount,(int)sortedMap.get(expectedAmount)-1);
                    denominations.put(expectedAmount,denominations.get(expectedAmount)-1);
                    if(denominations.get(expectedAmount).equals(0)){
                        denominations.remove(expectedAmount);
                    }
                    expectedAmount=0;
                }

            }
            else{
                Object denom= sortedMap.lowerKey(expectedAmount);
            if (denom==null){
                throw new NotEnoughMoneyException();
            }

            if((int)sortedMap.get(denom)>=1){
                if(used.containsKey(denom))
                used.put((int)denom,used.get(denom)+1);
                else
                    used.put((int)denom,1);
                sortedMap.put(denom,(int)sortedMap.get(denom)-1);
                denominations.put((int)denom,denominations.get(denom)-1);
                if(denominations.get(denom).equals(0)){
                    denominations.remove(denom);
                }
                expectedAmount=expectedAmount-(int)denom;
            }
        }}
        while (expectedAmount>0);
        for(Map.Entry e:used.entrySet()){
           ConsoleHelper.writeMessage(e.getKey()+" - "+e.getValue());
            ConsoleHelper.writeMessage("Operation successful");
        }
        return used;

    }
}
