package com.javarush.test.level26.lesson15.big01.command;

import com.javarush.test.level26.lesson15.big01.ConsoleHelper;
import com.javarush.test.level26.lesson15.big01.exception.InterruptOperationException;



/**
 * Created by alexander on 28.03.16.
 */
class ExitCommand implements Command

{
    @Override
    public void execute() throws InterruptOperationException
    {
        ConsoleHelper.writeMessage("Do you really want to leave?");
        if(ConsoleHelper.readString().equals("y")){
            ConsoleHelper.writeMessage("Bye");
        }

    }
}
