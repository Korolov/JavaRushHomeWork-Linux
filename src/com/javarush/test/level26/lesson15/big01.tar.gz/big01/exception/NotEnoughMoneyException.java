package com.javarush.test.level26.lesson15.big01.exception;

/**
 * Created by alexander on 28.03.16.
 */
public class NotEnoughMoneyException extends Exception
{
}
