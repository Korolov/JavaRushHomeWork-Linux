package com.javarush.test.level26.lesson15.big01;

import com.javarush.test.level26.lesson15.big01.exception.InterruptOperationException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by alexander on 28.03.16.
 */
public class ConsoleHelper
{
   final static  BufferedReader READER=new BufferedReader(new InputStreamReader(System.in));
    public static void writeMessage(String message){
        System.out.println(message);
    }

    public static String readString() throws InterruptOperationException
    {
        String result="";

        try{
            result=READER.readLine();
            if(result.equalsIgnoreCase("exit"))
                throw new InterruptOperationException();

        }
            catch(IOException ignored){

            }
        return result;
    }

    public static String askCurrencyCode() throws InterruptOperationException
    {
        String s;
        writeMessage("Enter currency code");
        s=readString();
        if(s.length()!=3){
            return askCurrencyCode();
        }
        else
            return s.toUpperCase();

    }

    public static String[] getValidTwoDigits(String currencyCode) throws InterruptOperationException
    {
        String money="";
        writeMessage("Please enter nominal and number of banknotes");
        try{
            money=readString();
            String a=money.split(" ")[0];
            String b=money.split(" ")[1];
            Integer.parseInt(a);
            Integer.parseInt(b);
        return  new String[]{a,b};}

        catch(ArrayIndexOutOfBoundsException e){
            return getValidTwoDigits(currencyCode);
        }
        catch (NumberFormatException e){
            return getValidTwoDigits(currencyCode);
        }
    }

    public static Operation askOperation() throws InterruptOperationException
    {
        writeMessage("What operation would you like to proceed with");

            return Operation.getAllowableOperationByOrdinal(Integer.parseInt(readString()));


    }


}
