package com.javarush.test.level27.lesson15.big01.ad;

import com.javarush.test.level27.lesson15.big01.ConsoleHelper;

import java.util.*;

/**
 * Created by alexander on 30.03.16.
 */
public  class AdvertisementManager
{
    private final AdvertisementStorage storage = AdvertisementStorage.getInstance();
private int timeSeconds;
    public AdvertisementManager(int timeSeconds)
    {
        this.timeSeconds=timeSeconds;
    }
    public  void processVideos() throws InterruptedException
    {

        if(storage.list().isEmpty())
            throw new NoVideoAvailableException();
        List<Advertisement>videos=storage.list();
        Collections.sort(videos, new Comparator<Advertisement>()
        {
            @Override
            public int compare(Advertisement advertisement, Advertisement t1)
            {
                int result= (int)(t1.getAmountPerOneDisplaying()-advertisement.getAmountPerOneDisplaying());
                if(result!=0)
                    return result;
                else
                    result= (int)((t1.getAmountPerOneDisplaying()/t1.getDuration())-(advertisement.getAmountPerOneDisplaying()/advertisement.getDuration()));
                return result;

            }
        });

        int count=0;
        ArrayList<Advertisement>videosToShow=new ArrayList<>();
        for(int i=0;i<videos.size();i++){
            if(count>=timeSeconds)
                break;
            if(count+videos.get(i).getDuration()<=timeSeconds){
                videosToShow.add(videos.get(i));
                videos.get(i).revalidate();
            }
        }
              if(videosToShow==null||videosToShow.isEmpty())
                  throw new NoVideoAvailableException();
               else{
                  for(Advertisement video:videosToShow){
                ConsoleHelper.writeMessage(video.getName()+" is displaying... "+video.amountPerOneDisplaying+", "+video.getAmountPerOneDisplaying()*1000/video.getDuration());
                count+=video.getDuration();
                video.revalidate();
                    Thread.sleep(video.getDuration());
                  }
              }
            }

        }



