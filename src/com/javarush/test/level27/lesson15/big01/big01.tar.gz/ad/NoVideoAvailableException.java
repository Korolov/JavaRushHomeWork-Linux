package com.javarush.test.level27.lesson15.big01.ad;

/**
 * Created by alexander on 30.03.16.
 */
public class NoVideoAvailableException extends RuntimeException
{
}
